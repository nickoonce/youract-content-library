=== Your ACT Content Library ===
Contributors: youract
Tags: accessibility, events, resources, custom post type
Requires at least: 6.7
Tested up to: 6.8
Requires PHP: 8.1
Stable tag: 1.0.7
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Structured Resources and Events library plugin for YourACT.net using native WordPress APIs.

== Description ==

Your ACT Content Library adds two structured content types to WordPress:

- Resources
- Events

The plugin is built for Accessibility Coalition for Transformation (ACT) use cases with an emphasis on:

- Data portability
- Accessibility-oriented admin and front-end output
- Time-zone aware event handling
- Maintainable architecture and restrained scope

Out of scope by design:

- Ticket sales
- Registration workflows
- Payment processing
- Calendar grid UIs
- Community account systems

== Installation ==

1. Upload the youract-content-library folder to /wp-content/plugins/.
2. Activate "Your ACT Content Library" in Plugins.
3. Visit Settings > Permalinks and save once if your environment requires manual rewrite refresh.

== Initial Setup ==

1. Confirm Resources and Events appear in wp-admin.
2. Review seeded terms in Resource Types and Event Types.
3. Add Topics and Geographic Scope terms relevant to your community.
4. Add the provided shortcodes to pages as needed.

== Shortcode Documentation ==

= [youract_resources] =

Displays a searchable, filterable Resource library.

Optional attributes:

- per_page (default: 10)

GET filters:

- youract_resource_keyword
- youract_resource_topic
- youract_resource_geography
- youract_resource_type
- youract_include_archived (editor-level users)

Pagination query var:

- youract_resources_page

= [youract_events] =

Displays Events with time-based scope.

Optional attributes:

- scope: upcoming, past, all (default: upcoming)
- per_page (default: 10)

Pagination query var:

- youract_events_page

= [youract_featured_resources limit="3"] =

Displays active featured Resources.

= [youract_upcoming_events limit="3"] =

Displays next upcoming Events based on UTC timestamps.

== Block Documentation ==

= YourACT Event Details (youract/event-details) =

Server-rendered block for the Site Editor and template editor.

- Intended for Event single templates.
- Uses the current Event context and renders the same structured details panel used on singular Event views.
- If this block is present in a rendered template, the plugin avoids appending a duplicate Event Details section via the_content.
- Supports a viewMode attribute: auto, full, compact.
- In Query Loop context, auto mode renders compact details for archive-friendly output.

== Field Documentation ==

= Resource Fields =

- External URL
- Source organization
- Resource summary
- Access notes
- Last reviewed (YYYY-MM-DD)
- Resource status: active, needs-review, archived
- Featured resource

= Event Fields =

- Event start UTC timestamp (stored)
- Event end UTC timestamp (stored)
- Event timezone
- All-day flag
- Event format: in-person, online, hybrid
- Event URL

Admin UI stores date/time input in selected event timezone and converts to UTC at save.

== Theme Integration Guidance ==

Templates can be overridden by placing files in your active theme:

- /youract-content-library/resource-card.php
- /youract-content-library/event-card.php
- /youract-content-library/resource-details.php
- /youract-content-library/event-details.php

Use hooks to customize output and behavior without editing plugin core.

== Accessibility Notes ==

The plugin uses:

- Semantic sections and heading structure
- Visible labels and descriptions for controls
- Keyboard-operable native form controls
- Focus-visible styling
- Non-color status text
- Non-JavaScript filter workflows

Final accessibility conformance depends on active theme styles and content quality.

== Data Retention Behavior ==

- Deactivation preserves all posts, terms, and metadata.
- Uninstall preserves all data by default.
- Data deletion on uninstall is opt-in only via:
- YOURACT_CONTENT_LIBRARY_DELETE_DATA constant set to true
- youract_delete_data_on_uninstall option set truthy

== Frequently Asked Questions ==

= Does this plugin require ACF or CPT UI? =

No. It uses only WordPress core APIs.

= Can editors include archived resources in the library filter? =

Yes. Users with edit capability can opt in using the "Include archived resources" filter.

= How are Event times stored? =

UTC Unix timestamps are stored. Admin entry/editing uses local time in the selected IANA timezone.

= Does the plugin output Event structured data? =

Yes, on singular Event pages when enough data is available for valid JSON-LD.

== Changelog ==

= 1.0.0 =

- Initial release.
- Added Resources and Events custom post types.
- Added Topics, Geographic Scope, Resource Types, and Event Types taxonomies.
- Added secure metadata registration and admin meta boxes.
- Added timezone-aware Event date/time validation and UTC conversion.
- Added accessible shortcodes and template override support.
- Added singular detail sections and Event JSON-LD output.

= 1.0.1 =

- Release packaging update.

= 1.0.2 =

- Added a server-rendered Event Details block for template editor use.
- Added loop-safe compact rendering behavior for archive Query Loop usage.
- Simplified Event admin list columns to title, format, start, and end.

= 1.0.3 =

- Fixed block inserter visibility for the Event Details dynamic block in the editor.

= 1.0.4 =

- Added explicit editor-side fallback block registration for environments that do not surface metadata-only dynamic blocks in inserter.

= 1.0.5 =

- Reduced the Event content model by removing venue, address, organizer, registration URL, cost, accessibility, accommodation, and last verified fields.
- Updated event date display so single-day ranges do not repeat the date.
- Applied upcoming-first ordering to frontend Event archive loops.

= 1.0.6 =

- Updated Event Details block output to hide heading, status, and disclaimer.
- Changed event link presentation to label "More Info" and show the URL as link text.

= 1.0.7 =

- Improved timezone handling to support WordPress timezone selection formats consistently.
- Updated Event date/time output to display the selected timezone value and include a PST conversion note.
- Removed Event status and registration deadline date/time fields from the Event admin meta box.
